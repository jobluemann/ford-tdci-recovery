"""ford-tdci-recovery package."""
